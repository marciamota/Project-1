# Udacity-Project-1-Eportfolio
Project 1 for the Udacity Front end web developer Nanodegree

##How to view
You can access the project two ways:
1. Clone the GitHub repository (https://github.com/jbuechs/Udacity-Project-1-Eportfolio) and open index.html
2. View the live website at http://jbuechs.github.io/Udacity-Project-1-Eportfolio/

##Project Overview
I created this website for the Udacity Front End Web Developer Nanodegree. For the project, I was provided a design mock-up as a pdf file, which I had to replicate using HTML and CSS. I was also able to make customizations and personalizations.

##What I Learned
In this project, I learned how to view a website design as boxes on a screen. I used Twitter Bootstrap to create a responsive design that displayed the webpage well on all screen sizes.
